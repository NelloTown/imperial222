console.log("test");

ScrollReveal().reveal('.reveal');